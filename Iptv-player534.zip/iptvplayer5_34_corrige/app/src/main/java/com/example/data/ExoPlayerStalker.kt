package com.example.data

import android.content.Context
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import java.net.URLEncoder

class ExoPlayerStalker(
    private val authManager: StalkerAuthManager
) {
    companion object {
        private const val TAG = "ExoPlayerStalker"
    }

    /**
     * Builds standard Stalker headers including User-Agent, Referer, Cookie, and Authorization.
     */
    fun buildStalkerHeaders(): Map<String, String> {
        val headers = mutableMapOf<String, String>()
        val portalUrl = authManager.getPortalUrl()
        val mac = authManager.getMacAddress()
        val token = authManager.getToken()

        headers["User-Agent"] = StalkerAuthManager.DEFAULT_USER_AGENT
        if (portalUrl.isNotEmpty()) {
            headers["Referer"] = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
        }
        if (mac.isNotEmpty()) {
            val deviceFields = generateStalkerDeviceFields(mac)
            val devId = deviceFields["device_id"] ?: ""
            var devId2 = deviceFields["device_id2"] ?: ""
            if (portalUrl.contains("deirnet.ps", ignoreCase = true)) {
                devId2 = ""
            }
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""
            
            headers["Cookie"] = "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=Europe/Kiev; token=$token"
            headers["X-User-Card"] = "mac=$mac; stb_lang=en; timezone=Europe/Kiev; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
        }
        if (token.isNotEmpty()) {
            headers["Authorization"] = "Bearer $token"
        }
        return headers
    }

    /**
     * Generates a MediaSource specifically configured with Stalker headers to bypass 401/403/404 errors.
     */
    fun createMediaSource(context: Context, streamUrl: String): MediaSource {
        Log.d(TAG, "Creating Stalker MediaSource for stream: $streamUrl")
        
        val stalkerHeaders = buildStalkerHeaders()
        
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setKeepPostFor302Redirects(true)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(25000)
            .setDefaultRequestProperties(stalkerHeaders)
            .setUserAgent(stalkerHeaders["User-Agent"] ?: StalkerAuthManager.DEFAULT_USER_AGENT)

        val defaultDataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)

        val tsFlags = androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS

        val extractorsFactory = androidx.media3.extractor.DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setConstantBitrateSeekingAlwaysEnabled(true)
            .setTsExtractorFlags(tsFlags)
            .setTsExtractorTimestampSearchBytes(3000 * 188)
            .setMatroskaExtractorFlags(androidx.media3.extractor.mkv.MatroskaExtractor.FLAG_DISABLE_SEEK_FOR_CUES)
            .setMp4ExtractorFlags(androidx.media3.extractor.mp4.Mp4Extractor.FLAG_WORKAROUND_IGNORE_EDIT_LISTS)
            .setMp3ExtractorFlags(androidx.media3.extractor.mp3.Mp3Extractor.FLAG_ENABLE_INDEX_SEEKING)
            .setAdtsExtractorFlags(androidx.media3.extractor.ts.AdtsExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)
            .setFlacExtractorFlags(androidx.media3.extractor.flac.FlacExtractor.FLAG_DISABLE_ID3_METADATA)
            .setAmrExtractorFlags(androidx.media3.extractor.amr.AmrExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)

        val mediaSourceFactory = DefaultMediaSourceFactory(context, extractorsFactory)
            .setDataSourceFactory(defaultDataSourceFactory)

        val mediaItemBuilder = MediaItem.Builder().setUri(streamUrl)
        
        val mimeType = when {
            streamUrl.contains(".m3u8", ignoreCase = true) || streamUrl.contains("type=m3u8", ignoreCase = true) || streamUrl.contains("format=m3u8", ignoreCase = true) -> {
                MimeTypes.APPLICATION_M3U8
            }
            streamUrl.contains(".ts", ignoreCase = true) || streamUrl.contains("output=ts", ignoreCase = true) || streamUrl.contains("format=ts", ignoreCase = true) -> {
                "video/mp2t"
            }
            streamUrl.contains(".mp4", ignoreCase = true) || streamUrl.contains("format=mp4", ignoreCase = true) -> {
                MimeTypes.VIDEO_MP4
            }
            streamUrl.contains(".mkv", ignoreCase = true) || streamUrl.contains("format=mkv", ignoreCase = true) -> {
                MimeTypes.VIDEO_MATROSKA
            }
            streamUrl.contains(".mpd", ignoreCase = true) -> {
                MimeTypes.APPLICATION_MPD
            }
            streamUrl.contains(".ism", ignoreCase = true) -> {
                MimeTypes.APPLICATION_SS
            }
            else -> null
        }
        
        if (mimeType != null) {
            mediaItemBuilder.setMimeType(mimeType)
        }

        val builtMediaItem = mediaItemBuilder.build()
        return if (mimeType == MimeTypes.APPLICATION_M3U8 || streamUrl.contains(".m3u8", ignoreCase = true)) {
            androidx.media3.exoplayer.hls.HlsMediaSource.Factory(defaultDataSourceFactory)
                .setAllowChunklessPreparation(false)
                .setExtractorFactory(androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory(tsFlags, true))
                .createMediaSource(builtMediaItem)
        } else {
            mediaSourceFactory.createMediaSource(builtMediaItem)
        }
    }

    /**
     * Applies Stalker stream configurations directly to an existing ExoPlayer instance.
     */
    fun playStream(context: Context, player: ExoPlayer, streamUrl: String, isMuted: Boolean = false) {
        player.stop()
        player.clearMediaItems()
        
        val mediaSource = createMediaSource(context, streamUrl)
        player.setMediaSource(mediaSource)
        player.playWhenReady = true
        player.volume = if (isMuted) 0f else 1f
        player.prepare()
        Log.d(TAG, "Started Stalker stream playback successfully.")
    }
}
