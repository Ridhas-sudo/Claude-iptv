package com.example

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StalkerPortalClient
import com.example.debug.GlobalDebugConsoleOverlay
import com.example.debug.GlobalDebugSystem
import com.example.ui.IptvAppScreen
import com.example.ui.IptvViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: IptvViewModel by viewModels()
    private lateinit var stalkerClient: StalkerPortalClient

    // UI state to mirror the background task status beautifully
    private var isTesting by mutableStateOf(false)
    private var handshakeStateMsg by mutableStateOf("Non démarré")
    private var handshakeSuccess by mutableStateOf<Boolean?>(null)
    private var profileStateMsg by mutableStateOf("Non démarré")
    private var profileSuccess by mutableStateOf<Boolean?>(null)
    private var channelsStateMsg by mutableStateOf("Non démarré")
    private var channelsSuccess by mutableStateOf<Boolean?>(null)
    private var stalkerChannelsList by mutableStateOf<List<StalkerPortalClient.Channel>>(emptyList())
    private var showFullIptv by mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GlobalDebugSystem.init(this)
        enableEdgeToEdge()

        val portalUrl = "http://xoxpl8k.me:80/c/"
        val macAddress = "00:1A:79:5A:2F:F9"

        stalkerClient = StalkerPortalClient(portalUrl, macAddress, this)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0B0E14) // SpaceDarkBg
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (showFullIptv) {
                            IptvAppScreen(viewModel = viewModel)
                        } else {
                            StalkerInspectorDashboard(
                                portalUrl = portalUrl,
                                macAddress = macAddress,
                                isTesting = isTesting,
                                handshakeMsg = handshakeStateMsg,
                                handshakeSuccess = handshakeSuccess,
                                profileMsg = profileStateMsg,
                                profileSuccess = profileSuccess,
                                channelsMsg = channelsStateMsg,
                                channelsSuccess = channelsSuccess,
                                channelsList = stalkerChannelsList,
                                onRetryTest = { runStalkerTest() },
                                onLaunchApp = { showFullIptv = true }
                            )
                        }

                        // Fixed visual debug console with bottom 40% height, monospace green text, auto-scroll, clear & close
                        GlobalDebugConsoleOverlay()
                    }
                }
            }
        }
    }

    private fun runStalkerTest() {
        if (isTesting) return
        isTesting = true
        handshakeStateMsg = "En cours..."
        handshakeSuccess = null
        profileStateMsg = "Attente handshake..."
        profileSuccess = null
        channelsStateMsg = "Attente profil..."
        channelsSuccess = null
        stalkerChannelsList = emptyList()

        // Étape 1: Handshake
        stalkerClient.handshake { success, message ->
            runOnUiThread {
                handshakeStateMsg = message ?: "Terminé"
                handshakeSuccess = success
                
                if (success) {
                    profileStateMsg = "En cours..."
                    // Étape 2: Get Profile
                    stalkerClient.getProfile { profileSuccessVal, profileMessage ->
                        runOnUiThread {
                            profileStateMsg = profileMessage ?: "Terminé"
                            profileSuccess = profileSuccessVal
                            
                            if (profileSuccessVal) {
                                channelsStateMsg = "En cours..."
                                // Étape 3: Get Channels
                                stalkerClient.getAllChannels { channelsSuccessVal, channelsMessage, channels ->
                                    runOnUiThread {
                                        channelsStateMsg = channelsMessage ?: "Terminé"
                                        channelsSuccess = channelsSuccessVal
                                        isTesting = false
                                        
                                        if (channelsSuccessVal && channels != null) {
                                            // Afficher les chaînes
                                            showChannels(channels)
                                        }
                                    }
                                }
                            } else {
                                channelsStateMsg = "Annulé (Échec Profil)"
                                channelsSuccess = false
                                isTesting = false
                            }
                        }
                    }
                } else {
                    profileStateMsg = "Annulé (Échec Handshake)"
                    profileSuccess = false
                    channelsStateMsg = "Annulé (Échec Handshake)"
                    channelsSuccess = false
                    isTesting = false
                }
            }
        }
    }

    private fun showChannels(channels: List<StalkerPortalClient.Channel>) {
        stalkerChannelsList = channels
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val currentChannel = viewModel.selectedChannel.value
        val isLive = currentChannel?.type == "Live" || currentChannel?.type == "TV"
        if (viewModel.isPlaying.value && viewModel.isFullScreen.value && isLive) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    val params = PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9))
                        .build()
                    enterPictureInPictureMode(params)
                } catch (e: Exception) {
                    Log.e("MainActivity", "Error entering PiP mode: ${e.message}")
                }
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        viewModel.setPipMode(isInPictureInPictureMode)
    }
}

@Composable
fun StalkerInspectorDashboard(
    portalUrl: String,
    macAddress: String,
    isTesting: Boolean,
    handshakeMsg: String,
    handshakeSuccess: Boolean?,
    profileMsg: String,
    profileSuccess: Boolean?,
    channelsMsg: String,
    channelsSuccess: Boolean?,
    channelsList: List<StalkerPortalClient.Channel>,
    onRetryTest: () -> Unit,
    onLaunchApp: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredChannels = remember(searchQuery, channelsList) {
        if (searchQuery.isBlank()) channelsList
        else channelsList.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Diagnostic Panel & Status
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .weight(0.42f)
                .background(Color(0xFF1E293B), shape = RoundedCornerShape(16.dp))
                .border(1.dp, Color(0x33FFFFFF), shape = RoundedCornerShape(16.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFF00E5FF).copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Dns, contentDescription = "Inspecteur", tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                }
                Column {
                    Text("INSPECTEUR PORTAIL", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Stalker Client v1.0", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Divider(color = Color(0x1AFFFFFF))

            // Credentials Info
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x15000000), shape = RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("Configuration Test :", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text("URL: $portalUrl", color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("MAC: $macAddress", color = Color.White, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }

            // Steps Progress list
            Text("Étapes de connexion", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            StepRow(
                stepNum = "Étape 1",
                stepName = "Handshake initial",
                message = handshakeMsg,
                success = handshakeSuccess
            )

            StepRow(
                stepNum = "Étape 2",
                stepName = "Lecture Profil",
                message = profileMsg,
                success = profileSuccess
            )

            StepRow(
                stepNum = "Étape 3",
                stepName = "Indexation Chaînes",
                message = channelsMsg,
                success = channelsSuccess
            )

            Spacer(modifier = Modifier.weight(1f))

            // Bottom Buttons
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRetryTest,
                    enabled = !isTesting,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Vérification...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RE-TESTER LA CONNEXION", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = onLaunchApp,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Tv, contentDescription = "App", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ACCÉDER À L'APPLICATION IPTV", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Right Column: Retrieved Channels Inspect List
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .weight(0.58f)
                .background(Color(0xFF1E293B), shape = RoundedCornerShape(16.dp))
                .border(1.dp, Color(0x33FFFFFF), shape = RoundedCornerShape(16.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Chaînes indexées", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("${channelsList.size} au total", color = Color.LightGray, fontSize = 11.sp)
                }

                // Small search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher...", color = Color.Gray, fontSize = 12.sp) },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontSize = 12.sp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0x1F000000),
                        unfocusedContainerColor = Color(0x1F000000),
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0x33FFFFFF)
                    ),
                    modifier = Modifier
                        .width(180.dp)
                        .height(42.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            Divider(color = Color(0x1AFFFFFF))

            if (channelsList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isTesting) Icons.Default.CloudSync else Icons.Default.Info,
                            contentDescription = "No channels",
                            tint = Color.Gray,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = if (isTesting) "Lecture du flux de données Stalker en cours..." else "Aucune chaîne chargée.\nLancez le test de connexion ci-contre.",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredChannels, key = { "${it.id}_${it.number}" }) { channel ->
                        ChannelDebugRow(channel = channel)
                    }
                }
            }
        }
    }
}

@Composable
fun StepRow(
    stepNum: String,
    stepName: String,
    message: String,
    success: Boolean?
) {
    val statusColor = when (success) {
        true -> Color(0xFF10B981)
        false -> Color(0xFFEF4444)
        null -> if (message == "En cours...") Color(0xFF3B82F6) else Color.Gray
    }

    val icon: ImageVector = when (success) {
        true -> Icons.Default.CheckCircle
        false -> Icons.Default.Error
        null -> if (message == "En cours...") Icons.Default.Cached else Icons.Default.HourglassEmpty
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x0CFFFFFF), shape = RoundedCornerShape(10.dp))
            .border(
                border = BorderStroke(1.dp, if (success == true) Color(0x2210B981) else Color(0x11FFFFFF)),
                shape = RoundedCornerShape(10.dp)
            )
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = stepName,
            tint = statusColor,
            modifier = Modifier.size(20.dp)
        )

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(stepName, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                Text(stepNum, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = message,
                color = if (success == false) Color(0xFFFCA5A5) else Color.LightGray,
                fontSize = 10.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
fun ChannelDebugRow(channel: StalkerPortalClient.Channel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x14000000), shape = RoundedCornerShape(10.dp))
            .border(1.dp, Color(0x12FFFFFF), shape = RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Channel Number / Box
        Box(
            modifier = Modifier
                .size(32.dp)
                .background(Color(0xFF3B82F6).copy(alpha = 0.12f), shape = RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF3B82F6).copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = channel.number.toString(),
                color = Color(0xFF60A5FA),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Channel Info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = channel.name,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "CMD: ${channel.cmd}",
                color = Color.Gray,
                fontSize = 9.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
        
        // Status tag
        Box(
            modifier = Modifier
                .background(Color(0x1F10B981), shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text("STALKER", color = Color(0xFF34D399), fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

