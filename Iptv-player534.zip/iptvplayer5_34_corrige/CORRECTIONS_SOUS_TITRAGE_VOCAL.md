# Corrections – sous-titrage vocal (Google TV)

## Bugs bloquants corrigés
1. **Sous-titres partiels jamais affichés** (`SherpaSubtitleManager`) : `lastPartialText` était écrasé avant le test
   « nouveau texte ? ». Résultat : rien ne s'affichait avant la fin de phrase (pause de 0,5–0,9 s). Le mode
   streaming fonctionne maintenant réellement.
2. **Repliement de spectre (aliasing)** : la décimation 48 kHz → 16 kHz prenait 1 échantillon sur 3 sans filtre.
   Nouveau pipeline : downmix → passe-bas 7 kHz (2 biquads) → interpolation linéaire avec état conservé entre buffers.
   Meilleure précision de reconnaissance.
3. **Audio perdu quand l'UI TV est chargée** : le worker attendait le thread principal (`withContext(Main)`).
   Les callbacks sont maintenant postés sans bloquer le décodage.
4. **Réglage de synchro sans effet en streaming** : les partiels contournaient le délai, et le délai annulait
   chaque résultat précédent. Remplacé par une vraie ligne à retard numérotée (les résultats périmés après
   seek/zapping sont ignorés). Le ViewModel consomme désormais un seul canal.
5. **Release/R8** : ajout de la règle ProGuard `-keep class com.k2fsa.sherpa.onnx.**` (sinon crash JNI en release).
6. **Langues** : `ru` utilisait le modèle français ; elle utilise maintenant le modèle multilingue. Pour les langues
   sans modèle streaming dédié (es, de, it, pt, tr) un avertissement est affiché au lieu d'un silence trompeur.
   Le même modèle n'est plus rechargé sous deux codes différents.

## Améliorations de confort
- Texte anglais du modèle (MAJUSCULES) converti en casse normale, majuscule initiale, « I » corrigé.
- Fenêtre glissante : jamais plus de ~2 lignes (96 car.) en partiel, 160 en final.
- Durée d'affichage : 1,5 s + 60 ms/caractère (2,5–8 s) au lieu de 4,5–18 s.
- Gain automatique lissé (plus de pompage entre chunks) ; indicateur « parole détectée » qui retombe au silence.
- 2 threads d'inférence sur les boîtiers ≥ 4 cœurs (1 thread ne tenait pas le temps réel sur A53/A55).
- Chargement des libs natives séparé (une lib absente n'empêche plus le chargement des autres).
- Calibrage auto sans délai artificiel de base (offset initial 0 ms au lieu de 120 ms).
- Regex de nettoyage : ne supprime plus un mot parlé comme « Source » ou « Traduction » en début de phrase.

## Non testé / à savoir
- Le code n'a pas pu être compilé ici (pas de SDK Android) : faire un build Android Studio et tester sur la TV.
- `LiveSubtitleWebSocketManager` et `server/` ne sont utilisés par aucun écran de l'app (code inutilisé).
- Le lecteur Multiview n'a pas de sous-titrage vocal (pas d'AudioProcessor).
- Pour es/de/it/pt/tr il faudrait ajouter de vrais modèles streaming dans `AVAILABLE_MODELS`.
